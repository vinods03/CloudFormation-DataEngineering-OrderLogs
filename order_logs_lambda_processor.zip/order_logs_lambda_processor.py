def lambda_handler(event, context):
    
    import boto3, json
    s3 = boto3.resource('s3')
    glue = boto3.client('glue')
    target_bucket_name = 'order-logs-staging-area'
    crawler_name = 'order-logs-glue-crawler'
    print(event)
     
    for i in event['Records']:
        s3_event = json.loads(i['body'])
        print(s3_event)
        
        for j in s3_event['Records']:
            source_bucket_name = j['s3']['bucket']['name']
            source_file_path = j['s3']['object']['key']
            source_file_name = source_file_path.split('/')[-1]
            source_file_size = str(j['s3']['object']['size']/1000)
            source_file_etag = j['s3']['object']['eTag']
            target_file_s3_url = 's3://' + target_bucket_name + '/' + source_file_name
            print('Name of the source bucket is: ', source_bucket_name)
            print('Name of the source file uploaded is: ', source_file_name)
            print('Size of the source file uploaded in KB is: ', source_file_size)
            print('ETag of the source file uploaded is: ', source_file_etag)
            print('S3 Uri for the staging file is: ', target_file_s3_url)
    
            try:
                s3.Object(target_bucket_name, source_file_name).copy_from(CopySource = source_bucket_name + '/' + source_file_path)
                # s3.Object(source_bucket_name, source_file_path).delete()
                # We want to retain the files in landing area for a week, to enable users to query incoming order logs in near real time
                print('Successfully moved ', source_bucket_name, '/', source_file_path, ' to ', target_bucket_name)
            except Exception as e:
                print('Unable to move the file ', source_file_name, ' from landing area to staging area. The exception is ', e)
    
    try:        
        glue.start_crawler(Name = crawler_name)
    except Exception as f:
        print('Unable to start the glue crawler ', crawler_name, '. The exception is ', f)
    
   